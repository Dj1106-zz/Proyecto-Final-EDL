import time
import tracemalloc
from array import array
from structures.stack import Stack
from structures.queue import Queue
from structures.priority_queue import PriorityQueue
from structures.linked_list import LinkedList


def benchmark_structure(name, insert_func, remove_func, iterations=10000):
    """
    Ejecuta pruebas de rendimiento sobre una estructura de datos.

    Args:
        name (str): Nombre de la estructura.
        insert_func (callable): Función de inserción.
        remove_func (callable): Función de eliminación.
        iterations (int): Número de operaciones a realizar.
    """
    print(f"\nBenchmarking: {name}")
    
    tracemalloc.start()
    start_time = time.perf_counter()
    for i in range(iterations):
        insert_func(f"mensaje {i}")
    insert_time = time.perf_counter() - start_time
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print(f"Inserción - Tiempo: {insert_time:.6f}s, Memoria pico: {peak / 1024:.2f} KB")

    tracemalloc.start()
    start_time = time.perf_counter()
    for _ in range(iterations):
        remove_func()
    remove_time = time.perf_counter() - start_time
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print(f"Eliminación - Tiempo: {remove_time:.6f}s, Memoria pico: {peak / 1024:.2f} KB")


def test_stack_vs_array(iterations=10000):
    """
    Compara el rendimiento entre una pila basada en lista y una basada en array.array.
    
    Args:
        iterations (int): Número de operaciones a realizar.
    """
    print("\nComparación: Stack (lista) vs array.array")

    s = Stack()
    benchmark_structure("Pila (lista)", s.push, s.pop, iterations)

    print("\nBenchmarking: Pila (array.array de enteros)")
    stack_array = array('i')

    def array_push(val):
        stack_array.append(int(val.split()[-1]))

    def array_pop():
        if stack_array:
            stack_array.pop()

    benchmark_structure("Pila (array.array)", array_push, array_pop, iterations)


def main():
    """
    Ejecuta benchmarks comparativos entre distintas estructuras de datos.
    """
    ITERATIONS = 10000

    test_stack_vs_array(ITERATIONS)

    q = Queue()
    benchmark_structure("Cola FIFO (lista)", q.enqueue, q.dequeue, ITERATIONS)

    pq = PriorityQueue()
    priority_counter = [0]

    def pq_enqueue(msg):
        pq.enqueue(priority_counter[0], msg)
        priority_counter[0] += 1

    benchmark_structure("Cola de prioridad (heapq)", pq_enqueue, pq.dequeue, ITERATIONS)

    ll = LinkedList()
    benchmark_structure("Lista enlazada (insert final, delete primero)", ll.insert, lambda: ll.delete(f"mensaje 0"), ITERATIONS)


if __name__ == "__main__":
    main()

