# src/message_manager.py
from structures.linked_list import LinkedList
from structures.queue import Queue
from structures.priority_queue import PriorityQueue
from structures.stack import Stack

class MessageManager:
    """Clase para gestionar mensajes dentro del sistema de mensajería."""
    def __init__(self):
        self.history = LinkedList()
        self.queue = Queue()
        self.priority_queue = PriorityQueue()
        self.undo_stack = Stack()

    def send_message(self, message, priority=None):
        """Envía un mensaje, almacenándolo en el historial y en la cola correspondiente."""
        if priority is not None:
            self.priority_queue.enqueue(message, priority)
        else:
            self.queue.enqueue(message)
        self.history.insert(message)

    def receive_message(self):
        """Recibe un mensaje desde la cola normal o la cola de prioridad."""
        if not self.priority_queue.is_empty():
            return self.priority_queue.dequeue()
        elif not self.queue.is_empty():
            return self.queue.dequeue()
        return None

    def delete_message(self, message):
        """Elimina un mensaje del historial y lo guarda en la pila para recuperación."""
        if self.history.delete(message):
            self.undo_stack.push(message)
            return True
        return False

    def undo_delete(self):
        """Recupera el último mensaje eliminado."""
        if not self.undo_stack.is_empty():
            restored_message = self.undo_stack.pop()
            self.history.insert(restored_message)
            return restored_message
        return None

    def show_history(self):
        """Muestra el historial de mensajes."""
        return self.history.traverse()
