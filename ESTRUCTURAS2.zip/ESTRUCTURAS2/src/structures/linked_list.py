# src/structures/linked_list.py

class Node:
    """Clase que representa un nodo en una lista enlazada."""
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    """Implementación de una lista enlazada simple para almacenar mensajes."""
    def __init__(self):
        self.head = None

    def insert(self, data):
        """Inserta un nuevo mensaje al final del historial."""
        new_node = Node(data)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    def delete(self, data):
        """Elimina un mensaje del historial si existe."""
        if not self.head:
            return False
        if self.head.data == data:
            self.head = self.head.next
            return True
        
        current = self.head
        while current.next:
            if current.next.data == data:
                current.next = current.next.next
                return True
            current = current.next
        return False

    def search(self, data):
        """Busca un mensaje en el historial."""
        current = self.head
        while current:
            if current.data == data:
                return True
            current = current.next
        return False

    def traverse(self):
        """Devuelve una lista con todos los mensajes del historial."""
        messages = []
        current = self.head
        while current:
            messages.append(current.data)
            current = current.next
        return messages

    def size(self):
        """Retorna el número total de mensajes en el historial."""
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count
