import heapq

class PriorityQueue:
    """Implementación de una cola de prioridad basada en heap."""
    def __init__(self):
        self.queue = []

    def enqueue(self, priority, data):
        """Inserta un mensaje con prioridad."""
        heapq.heappush(self.queue, (priority, data))

    def dequeue(self):
        """Elimina y retorna el mensaje con mayor prioridad (menor valor numérico)."""
        if not self.is_empty():
            return heapq.heappop(self.queue)[1]  # Devuelve solo el mensaje
        return None

    def peek(self):
        """Retorna el mensaje con mayor prioridad sin eliminarlo."""
        if not self.is_empty():
            return self.queue[0][1]  # Devuelve solo el mensaje
        return None

    def is_empty(self):
        """Retorna True si la cola está vacía, False en caso contrario."""
        return len(self.queue) == 0

    def size(self):
        """Retorna el número de elementos en la cola de prioridad."""
        return len(self.queue)

    def traverse(self):
        """Devuelve una lista de tuplas (prioridad, mensaje) ordenadas por prioridad."""
        return sorted(self.queue)
