# src/structures/queue.py

class Queue:
    """Implementación de una cola basada en lista para manejar mensajes en orden de llegada."""
    def __init__(self):
        self.queue = []

    def enqueue(self, data):
        """Inserta un mensaje al final de la cola."""
        self.queue.append(data)

    def dequeue(self):
        """Elimina y retorna el primer mensaje de la cola."""
        if not self.is_empty():
            return self.queue.pop(0)
        return None

    def front(self):
        """Retorna el primer mensaje sin eliminarlo."""
        if not self.is_empty():
            return self.queue[0]
        return None

    def is_empty(self):
        """Retorna `True` si la cola está vacía, `False` en caso contrario."""
        return len(self.queue) == 0

    def size(self):
        """Retorna el número total de mensajes en la cola."""
        return len(self.queue)

    def traverse(self):
        """Devuelve una lista con los mensajes en orden."""
        return self.queue[:]
