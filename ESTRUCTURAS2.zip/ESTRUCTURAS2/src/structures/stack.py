# src/structures/stack.py

class Stack:
    """Implementación de una pila basada en lista para gestionar mensajes eliminados."""
    def __init__(self):
        self.stack = []

    def push(self, data):
        """Inserta un elemento en la cima de la pila."""
        self.stack.append(data)

    def pop(self):
        """Elimina y retorna el elemento superior de la pila."""
        if not self.is_empty():
            return self.stack.pop()
        return None

    def peek(self):
        """Retorna el elemento superior sin eliminarlo."""
        if not self.is_empty():
            return self.stack[-1]
        return None

    def is_empty(self):
        """Retorna `True` si la pila está vacía, `False` en caso contrario."""
        return len(self.stack) == 0

    def size(self):
        """Retorna el número total de elementos en la pila."""
        return len(self.stack)
