# src/tests/test_linked_list.py
import unittest
from structures.linked_list import LinkedList

class TestLinkedList(unittest.TestCase):
    def setUp(self):
        """Inicializa una lista enlazada antes de cada prueba."""
        self.linked_list = LinkedList()

    def test_insert(self):
        """Verifica que los elementos se insertan correctamente."""
        self.linked_list.insert("Mensaje 1")
        self.linked_list.insert("Mensaje 2")
        self.assertEqual(self.linked_list.traverse(), ["Mensaje 1", "Mensaje 2"])

    def test_delete(self):
        """Verifica que la eliminación funciona correctamente."""
        self.linked_list.insert("Mensaje 1")
        self.linked_list.insert("Mensaje 2")
        self.linked_list.delete("Mensaje 1")
        self.assertEqual(self.linked_list.traverse(), ["Mensaje 2"])

    def test_search(self):
        """Verifica que la búsqueda de mensajes funciona."""
        self.linked_list.insert("Mensaje importante")
        self.assertTrue(self.linked_list.search("Mensaje importante"))
        self.assertFalse(self.linked_list.search("Mensaje inexistente"))

    def test_size(self):
        """Verifica que el tamaño de la lista se calcula correctamente."""
        self.assertEqual(self.linked_list.size(), 0)
        self.linked_list.insert("Mensaje 1")
        self.assertEqual(self.linked_list.size(), 1)
        self.linked_list.insert("Mensaje 2")
        self.assertEqual(self.linked_list.size(), 2)

if __name__ == "__main__":
    unittest.main()
