# src/tests/test_priority_queue.py
import unittest
from structures.priority_queue import PriorityQueue

class TestPriorityQueue(unittest.TestCase):
    def setUp(self):
        """Inicializa una cola de prioridad antes de cada prueba."""
        self.priority_queue = PriorityQueue()

    def test_enqueue_dequeue(self):
        """Verifica que los mensajes se insertan y extraen según prioridad."""
        self.priority_queue.enqueue("Mensaje normal", priority=2)
        self.priority_queue.enqueue("Mensaje urgente", priority=1)
        self.assertEqual(self.priority_queue.dequeue(), "Mensaje urgente")
        self.assertEqual(self.priority_queue.dequeue(), "Mensaje normal")
        self.assertTrue(self.priority_queue.is_empty())

    def test_peek(self):
        """Verifica que el método peek muestra el mensaje con mayor prioridad."""
        self.priority_queue.enqueue("Mensaje normal", priority=2)
        self.priority_queue.enqueue("Mensaje urgente", priority=1)
        self.assertEqual(self.priority_queue.peek(), "Mensaje urgente")

    def test_is_empty(self):
        """Verifica que la cola de prioridad detecta correctamente si está vacía."""
        self.assertTrue(self.priority_queue.is_empty())
        self.priority_queue.enqueue("Mensaje 1", priority=1)
        self.assertFalse(self.priority_queue.is_empty())

    def test_size(self):
        """Verifica que el tamaño de la cola de prioridad se calcula correctamente."""
        self.assertEqual(self.priority_queue.size(), 0)
        self.priority_queue.enqueue("Mensaje 1", priority=1)
        self.assertEqual(self.priority_queue.size(), 1)
        self.priority_queue.enqueue("Mensaje 2", priority=2)
        self.assertEqual(self.priority_queue.size(), 2)

if __name__ == "__main__":
    unittest.main()
