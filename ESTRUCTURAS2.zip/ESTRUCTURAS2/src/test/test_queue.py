# src/tests/test_queue.py
import unittest
from structures.queue import Queue

class TestQueue(unittest.TestCase):
    def setUp(self):
        """Inicializa una cola antes de cada prueba."""
        self.queue = Queue()

    def test_enqueue_dequeue(self):
        """Verifica que la inserción y eliminación en la cola funcionan correctamente."""
        self.queue.enqueue("Mensaje 1")
        self.queue.enqueue("Mensaje 2")
        self.assertEqual(self.queue.dequeue(), "Mensaje 1")
        self.assertEqual(self.queue.dequeue(), "Mensaje 2")
        self.assertTrue(self.queue.is_empty())

    def test_front(self):
        """Verifica que el método front retorna el primer mensaje sin eliminarlo."""
        self.queue.enqueue("Mensaje importante")
        self.assertEqual(self.queue.front(), "Mensaje importante")
        self.assertFalse(self.queue.is_empty())

    def test_is_empty(self):
        """Verifica que la cola detecta correctamente si está vacía."""
        self.assertTrue(self.queue.is_empty())
        self.queue.enqueue("Mensaje 1")
        self.assertFalse(self.queue.is_empty())

    def test_size(self):
        """Verifica que el tamaño de la cola se calcula correctamente."""
        self.assertEqual(self.queue.size(), 0)
        self.queue.enqueue("Mensaje 1")
        self.assertEqual(self.queue.size(), 1)
        self.queue.enqueue("Mensaje 2")
        self.assertEqual(self.queue.size(), 2)

if __name__ == "__main__":
    unittest.main()
