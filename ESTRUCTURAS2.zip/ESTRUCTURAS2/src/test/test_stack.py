# src/tests/test_stack.py
import unittest
from structures.stack import Stack

class TestStack(unittest.TestCase):
    def setUp(self):
        """Inicializa una pila antes de cada prueba."""
        self.stack = Stack()

    def test_push_pop(self):
        """Verifica que los elementos se agregan y eliminan correctamente."""
        self.stack.push("Mensaje 1")
        self.stack.push("Mensaje 2")
        self.assertEqual(self.stack.pop(), "Mensaje 2")
        self.assertEqual(self.stack.pop(), "Mensaje 1")
        self.assertTrue(self.stack.is_empty())

    def test_peek(self):
        """Verifica que el método peek retorna el elemento correcto sin eliminarlo."""
        self.stack.push("Mensaje importante")
        self.assertEqual(self.stack.peek(), "Mensaje importante")
        self.assertFalse(self.stack.is_empty())

    def test_is_empty(self):
        """Verifica que la pila detecta correctamente si está vacía."""
        self.assertTrue(self.stack.is_empty())
        self.stack.push("Mensaje 1")
        self.assertFalse(self.stack.is_empty())

    def test_size(self):
        """Verifica que el tamaño de la pila se calcula correctamente."""
        self.assertEqual(self.stack.size(), 0)
        self.stack.push("Mensaje 1")
        self.assertEqual(self.stack.size(), 1)
        self.stack.push("Mensaje 2")
        self.assertEqual(self.stack.size(), 2)

if __name__ == "__main__":
    unittest.main()
