import tkinter as tk
from tkinter import messagebox, filedialog
import json
from structures.linked_list import LinkedList
from structures.queue import Queue
from structures.priority_queue import PriorityQueue
from structures.stack import Stack


class MessagingApp:
    """
    Interfaz gráfica para el sistema de mensajería, implementada con Tkinter.
    Utiliza estructuras de datos personalizadas para gestionar mensajes, historial,
    prioridades y operaciones de deshacer.
    """
    def __init__(self, root):
        self.root = root
        self.root.title("📩 Sistema de Mensajería 📩")
        self.root.geometry("500x600")

        self.history = LinkedList()
        self.message_queue = Queue()
        self.priority_queue = PriorityQueue()
        self.undo_stack = Stack()

        self.entry_msg = tk.Entry(root, width=40)
        self.entry_msg.pack(pady=10)

        self.btn_send = tk.Button(root, text="Enviar Mensaje", command=self.send_message)
        self.btn_send.pack(pady=5)

        self.btn_delete = tk.Button(root, text="Eliminar Seleccionado", command=self.delete_message)
        self.btn_delete.pack(pady=5)

        self.btn_undo = tk.Button(root, text="Deshacer Eliminación", command=self.undo_delete)
        self.btn_undo.pack(pady=5)

        self.search_entry = tk.Entry(root, width=30)
        self.search_entry.pack(pady=5)

        self.btn_search = tk.Button(root, text="Buscar Mensaje", command=self.search_message)
        self.btn_search.pack(pady=5)

        self.message_list = tk.Listbox(root, width=50, height=15)
        self.message_list.pack(pady=10)

        self.btn_edit = tk.Button(root, text="Editar Mensaje", command=self.edit_message)
        self.btn_edit.pack(pady=5)

        self.btn_save = tk.Button(root, text="Guardar Mensajes", command=self.save_messages)
        self.btn_save.pack(pady=5)

        self.btn_filter_priority = tk.Button(root, text="Mostrar Mensajes Prioritarios", command=self.show_priority_messages)
        self.btn_filter_priority.pack(pady=5)

        self.root.configure(bg="lightblue")

        self.btn_send_priority = tk.Button(root, text="Enviar Mensaje Prioritario", command=self.send_priority_message)
        self.btn_send_priority.pack(pady=5)

        self.showing_priority_only = False

    def send_message(self):
        """Envía un mensaje común, lo registra y lo muestra en la lista."""
        message = self.entry_msg.get()
        if message:
            self.history.insert(message)
            self.message_queue.enqueue(message)
            self.message_list.insert(tk.END, message)
            self.entry_msg.delete(0, tk.END)

    def delete_message(self):
        """Elimina el mensaje seleccionado, lo guarda en la pila de deshacer."""
        selected_index = self.message_list.curselection()
        if selected_index:
            message = self.message_list.get(selected_index)
            if self.history.delete(message):
                self.undo_stack.push(message)
                self.message_list.delete(selected_index)
                messagebox.showinfo("Eliminado", f"Mensaje eliminado: {message}")
        else:
            messagebox.showwarning("Error", "Seleccione un mensaje para eliminar.")

    def undo_delete(self):
        """Deshace la última eliminación y restaura el mensaje en la lista."""
        if not self.undo_stack.is_empty():
            restored_msg = self.undo_stack.pop()
            self.history.insert(restored_msg)
            self.message_list.insert(tk.END, restored_msg)
            messagebox.showinfo("Recuperado", f"Mensaje restaurado: {restored_msg}")
        else:
            messagebox.showwarning("Error", "No hay mensajes para recuperar.")

    def search_message(self):
        """Busca un mensaje en la lista visual y lo resalta si lo encuentra."""
        query = self.search_entry.get()
        if query:
            for i in range(self.message_list.size()):
                if query.lower() in self.message_list.get(i).lower():
                    self.message_list.selection_set(i)
                    return
            messagebox.showwarning("Error", "Mensaje no encontrado.")

    def edit_message(self):
        """Permite editar el contenido del mensaje seleccionado."""
        selected_index = self.message_list.curselection()
        if selected_index:
            message = self.message_list.get(selected_index)
            new_message = tk.simpledialog.askstring("Editar Mensaje", f"Editar '{message}':")
            if new_message:
                self.message_list.delete(selected_index)
                self.message_list.insert(selected_index, new_message)
                self.history.delete(message)
                self.history.insert(new_message)
        else:
            messagebox.showwarning("Error", "Seleccione un mensaje para editar.")

    def save_messages(self):
        """Guarda todos los mensajes del historial en un archivo JSON."""
        messages = self.history.traverse()
        with open("messages.json", "w") as file:
            json.dump(messages, file)
        messagebox.showinfo("Guardado", "Mensajes guardados correctamente.")

    def show_priority_messages(self):
        """
        Alterna entre mostrar solo los mensajes prioritarios y mostrar todos los mensajes.
        """
        if self.showing_priority_only:
            self.reload_all_messages()
            self.showing_priority_only = False
            self.btn_filter_priority.config(text="Mostrar Mensajes Prioritarios")
        else:
            if self.priority_queue.is_empty():
                messagebox.showinfo("Sin Prioritarios", "No hay mensajes prioritarios para mostrar.")
                return

            self.message_list.delete(0, tk.END)
            priority_messages = self.priority_queue.traverse()
            for _, message in priority_messages:
                self.message_list.insert(tk.END, message)

            self.showing_priority_only = True
            self.btn_filter_priority.config(text="Mostrar Todos los Mensajes")

    def send_priority_message(self):
        """Solicita prioridad y envía un mensaje como prioritario si es válido."""
        message = self.entry_msg.get()
        if message:
            try:
                priority = int(tk.simpledialog.askstring("Prioridad", "Ingresa prioridad (1 a 10):"))
                if 1 <= priority <= 10:
                    self.history.insert(message)
                    self.message_queue.enqueue(message)
                    self.priority_queue.enqueue(priority, message)
                    self.message_list.insert(tk.END, message)
                    self.entry_msg.delete(0, tk.END)
                else:
                    messagebox.showerror("Error", "La prioridad debe estar entre 1 y 10.")
            except (ValueError, TypeError):
                messagebox.showerror("Error", "Prioridad inválida.")
    
    def reload_all_messages(self):
        """Recarga todos los mensajes del historial en la lista."""
        self.message_list.delete(0, tk.END)
        for message in self.history.traverse():
            self.message_list.insert(tk.END, message)


if __name__ == "__main__":
    root = tk.Tk()
    app = MessagingApp(root)
    root.mainloop()
